// Importing necessary libraries
import javax.swing.*;
import java.awt.event.*;

// Main class
public class MainFrame extends JFrame {

    // Constructor for MainFrame
    public MainFrame() {
        // Setting the title
        setTitle("Test Application");

        // Setting the size to 800x600
        setSize(800, 600);

        // Disabling the maximize button
        setResizable(false);

        // Creating a 'test' button
        JButton testButton = new JButton("Test");
        testButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Displaying a message box with 'gg' when the 'test' button is pressed
                JOptionPane.showMessageDialog(null, "gg");
            }
        });

        // Adding the 'test' button to the frame
        add(testButton);

        // Setting the default close operation
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Setting the layout to null for absolute positioning
        setLayout(null);

        // Positioning the 'test' button
        testButton.setBounds(350, 275, 100, 30);
    }

    // Main method
    public static void main(String[] args) {
        // Creating an instance of MainFrame
        MainFrame myFrame = new MainFrame();

        // Making the frame visible
        myFrame.setVisible(true);
    }
}